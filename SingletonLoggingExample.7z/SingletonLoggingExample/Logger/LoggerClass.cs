﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logger
{
    public sealed class LoggerClass :ILog
    {
        private LoggerClass()
        {

        }

        private static readonly Lazy<LoggerClass> lazy = new Lazy<LoggerClass>(() => new LoggerClass());
        public static LoggerClass createInstance
        {
            get
            {
                return lazy.Value;
            }
        }

        public void LogException(string errorType, string errorMessage)
        {
            string fileName = string.Format("{0}_{1}.log", errorType, DateTime.Now.ToShortDateString());
            string logFilePath = string.Format(@"{0}\{1}", AppDomain.CurrentDomain.BaseDirectory, fileName);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("----------------------------------------");
            sb.AppendLine(DateTime.Now.ToString());
            sb.AppendLine(errorMessage);
            using (StreamWriter writer = new StreamWriter(logFilePath, true))
            {
                writer.Write(sb.ToString());
                writer.Flush();
            }
        }
    }
}
