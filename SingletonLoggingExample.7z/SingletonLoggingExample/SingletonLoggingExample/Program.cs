﻿using Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonLoggingExample
{
    class Program
    {
        static void Main(string[] args)
        {
            ILog _log = LoggerClass.createInstance;
            _log.LogException("Error", "Testing Exception");
            Console.WriteLine("Logging is done");
            Console.ReadKey();
        }
    }
}
