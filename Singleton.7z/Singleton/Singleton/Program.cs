﻿using MySingletonProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    class Program
    {
        static void Main(string[] args)
        {
            //Singleton by definition means there is going to be only one in existance per app domain
            MySingletonClass first = MySingletonClass.Instance;   // creates a new instance
            MySingletonClass second = MySingletonClass.Instance; // here it works on the same instance created above-hence singleton

            // two varaibles first and second are set to an singleton instance
            //now these two objects point to the same item on heap.

            if(first == second)
            {
                Console.WriteLine("Both variables point to the same item");
            }

            first.someValue++;
            if(first.someValue == second.someValue)
            {
                Console.WriteLine("Both variables are the same after first.someValue++");
            }
            second.someValue++;
            if (first.someValue == second.someValue)
            {
                Console.WriteLine("Both variables are the same after second.someValue++");
            }
        }
    }
}
