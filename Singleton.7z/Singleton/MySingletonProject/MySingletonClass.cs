﻿using System;

namespace MySingletonProject
{
    public class MySingletonClass 
    {
        //volatile keyword fixed the double lock issue
        private static volatile MySingletonClass _instance;
        private static readonly object _syncLock = new object();
        private MySingletonClass()
        {

        }

        //Static property called Instance
        public static MySingletonClass Instance
        {
            get
            {
                // checking if the private static instance variable is not null, then an instance is already created
                // hence return the created one
                if (_instance != null) return _instance;
                lock(_syncLock) //otherwise you are creating a lock so that it makes the code single threaded
                {
                    if(_instance == null) // we are checking this becoz potentially multiple threads come in, if one gets through and makes
                    {                     // an instance, the other will also try to make an instance.
                        _instance = new MySingletonClass();
                    }
                    return _instance;
                }
            }

        }

        public double someValue { get; set; }

    }
}
