﻿using MySingletonProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calc = Calculator.createInstance;
            var addResult = calc.AddNumbers(10, 20);
            var subResult = calc.subNumbers(30, 10);
            Console.WriteLine("Results of addition:" + addResult);
            Console.WriteLine("Results of subtraction:" + subResult);
            Console.ReadKey();
        }
    }
}
