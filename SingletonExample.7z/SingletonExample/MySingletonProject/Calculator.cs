﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySingletonProject
{
    public class Calculator
    {
        private static volatile Calculator _calcInstance;
        private static readonly object _synclock = new object();
        private Calculator()
        {

        }

        public static Calculator createInstance
        {
            get
            {
                if (_calcInstance != null) return _calcInstance; 
                lock(_synclock)
                {
                    if(_calcInstance == null)
                    {
                        _calcInstance = new Calculator();
                        
                    }
                    return _calcInstance;
                }
            }
        }

        public double AddNumbers(double x, double y)
        {
            return x + y;
        }

        public double subNumbers(double x, double y)
        {
            return x - y;
        }
    }
}
