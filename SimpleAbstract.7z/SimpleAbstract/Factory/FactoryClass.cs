﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory
{
    public static class FactoryClass
    {
        private static Dictionary<string, CustomerModel> custDict = new Dictionary<string, CustomerModel>();
        public static CustomerModel createInstance(string typeOfCust)
        {
            if(custDict.Count == 0)
            {
                custDict.Add("Visitor", new VisitorModel());
                custDict.Add("Buyer", new BuyerModel());

            }
            return custDict[typeOfCust];

        }

    }
}
