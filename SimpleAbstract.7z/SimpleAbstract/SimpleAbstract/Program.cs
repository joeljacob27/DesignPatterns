﻿using Factory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleAbstract
{
    class Program
    {
        static void Main(string[] args)
        {
            var visitor = FactoryClass.createInstance("Visitor");
            visitor.custMobile = "985855222144";
            visitor.custAddress = "Address1";
            visitor.custCountry = "Country 1";

            var buyer = FactoryClass.createInstance("Buyer");
            buyer.custAddress = "Address2";
            buyer.custCountry = "Country 2";
            buyer.custMobile = "9858888844";

            var valVisitor = visitor.validate();
            var valBuyer = buyer.validate();

            Console.ReadKey();

        }
    }
}
