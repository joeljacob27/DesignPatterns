﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class CustomerModel
    {
        public string custType { get; set; }
        public string custMobile { get; set; }
        public string custAddress { get; set; }
        public string custCountry { get; set; }

        public virtual bool validate()
        {
            throw new Exception($"No overriding done");
        }
    }

    public class VisitorModel:CustomerModel
    {
        public override bool validate()
        {
            if (custMobile.Length == 0)
            {
                return false;
            }
            return true;
        }

    }

    public class BuyerModel:CustomerModel
    {
        public override bool validate()
        {
            if (custMobile.Length == 0 || custAddress.Length == 0 || custCountry.Length == 0)
            {
                return false;
            }
            return true;
        }
    }



}
